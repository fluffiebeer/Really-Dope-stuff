class CfgPatches
{
	class Seph_Katana
	{
		units[]={};
		weapons[]={};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"DZ_Data",
			"DZ_Weapons_Melee"
		};
	};
};
class CfgVehicles
{
	class BaseballBat;
	class KBAD_Sephiroth_Katana: BaseballBat
	{
		scope=2;
		displayName="Sephiroth's Katana";
		descriptionShort="This Legendary Weapon is called Masamune, It was once wielded by the legendary First Class Soldier, Named Sephiroth, After the Nibelheim accident no one knows what happened to him. Some say is the closest thing to God.";
		model="clouds_weapons\seph_katana\sephiroth_katana.p3d";
		inventorySlot[]=
		{
			"Shoulder",
			"Melee"
		};
		SingleUseActions[]={533};
		ContinuousActions[]={168,193};
		build_action_type=10;
		dismantle_action_type=0;
		itemSize[] = {1,9};
		rotationFlags=17;
		weight=250;
		fragility=0.0080000004;
		openItemSpillRange[]={0,0};
		};
	};
};