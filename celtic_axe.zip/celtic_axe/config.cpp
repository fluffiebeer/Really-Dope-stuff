class CfgPatches
{
	class Celtic_Axe
	{
		units[]={};
		weapons[]={};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"DZ_Data",
			"DZ_Gear_Tools"
		};
	};
};
class CfgMods
{
	class KBAD_Celtic_Axe
	{	
		
		dir = "clouds_weapons";
		picture = "";
		action = "";
		hideName = 1;
		hidePicture = 1;
		name = "KBAD_Celtic_Axe Module";
		type = "mod";
	};
};

class CfgVehicles
{
	class Hatchet;
	class KBAD_Celtic_Axe_Base: Hatchet
	{
		scope=0;
		displayName="Celtic Axe";
		descriptionShort="Axe of a Celtic Warrior, Created By Cloud";
		model="clouds_weapons\celtic_axe\ca.p3d";
		inventorySlot[]=
		{
			"Shoulder",
			"Melee"
		};
		SingleUseActions[]={533};
		ContinuousActions[]={168,193};
		build_action_type=10;
		dismantle_action_type=0;
		rotationFlags=17;
		weight=940;
		itemSize[]={2,3};
		fragility=0.0080000004;
		openItemSpillRange[]={0,0};
	};
    class KBAD_Celtic_Axe: KBAD_Celtic_Axe_Base
    {
        scope = 2;
		displayName="Celtic Axe";
		descriptionShort="Axe of a Celtic Warrior, Created By Cloud";
	};
};