class CfgPatches
{
	class Mjolnir
	{
		units[]={};
		weapons[]={};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"DZ_Data",
			"DZ_Gear_Tools"
		};
	};
};
class CfgVehicles
{
	class Hammer;
	class OF_Mjolnir: Hammer
	{
		scope=2;
		displayName="Mjolnir";
		descriptionShort="Thor's Hammer - Created by Cloud, Whosoever holds this hammer, if they be worthy, shall possess the power of Thor.";
		model="clouds_weapons\mjolnir\bk.p3d";
		inventorySlot[]=
		{
			"Shoulder",
			"Melee"
		};
		SingleUseActions[]={533};
		ContinuousActions[]={168,193};
		build_action_type=10;
		dismantle_action_type=0;
		rotationFlags=12;
		weight=940;
		itemSize[]={2,3};
		itemBehaviour=2;
		fragility=0.0080000004;
		openItemSpillRange[]={20,50};
	};
};