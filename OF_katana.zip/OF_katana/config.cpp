class CfgPatches
{
	class Katana
	{
		units[]={};
		weapons[]={};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"DZ_Data",
			"DZ_Weapons_Melee"
		};
	};
};
class CfgVehicles
{
	class CombatKnife;
	class Fluffie_Customs: CombatKnife
	{
		scope=2;
		displayName="Old Katana";
		descriptionShort="";
		model="clouds_weapons\kumorai_katana\kt.p3d";
		inventorySlot[]=
		{
			"Shoulder",
			"Melee"
		};
		SingleUseActions[]={533};
		ContinuousActions[]={168,193};
		build_action_type=10;
		dismantle_action_type=0;
		rotationFlags=17;
		weight=940;
		itemSize[]={1,6};
		fragility=0.0080000004;
		openItemSpillRange[]={20,50};
		};
	};
};