class CfgPatches
{
	class MjolnirV3
	{
		units[]={};
		weapons[]={};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"DZ_Data",
			"DZ_Gear_Tools"
		};
	};
};
class CfgVehicles
{
	class Hammer;
	class KBAD_Mjolnir_Base_V3: Hammer
	{
		scope=0;
		displayName="Mjolnir v3";
		descriptionShort="Thor's Hammer - Created by Cloud, Whosoever holds this hammer, if they be worthy, shall possess the power of Thor.";
		model="clouds_weapons\mjolnir_v3\mol.p3d";
		inventorySlot[]=
		{
			"Shoulder",
			"Melee"
		};
		SingleUseActions[]={533};
		ContinuousActions[]={168,193};
		build_action_type=10;
		dismantle_action_type=0;
		rotationFlags=12;
		weight=940;
		itemSize[]={2,3};
		itemBehaviour=2;
		fragility=0.0080000004;
		openItemSpillRange[]={20,50};
	};
    class KBAD_Mjolnir_V3: KBAD_Mjolnir_Base_V3
    {
        scope = 2;
		displayName="Mjolnir V3";
		descriptionShort="Mjolnir V3, Created by Cloud";
    };
};
